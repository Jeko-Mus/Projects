import pandas as pd
import matplotlib as plt
import numpy
from scraping import get_movies

get_movies('https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=crime&sort=user_rating,desc&ref_=adv_prv', 'data_1')
get_movies('https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=crime&sort=user_rating,desc&start=51&ref_=adv_nxt', 'data_2')
